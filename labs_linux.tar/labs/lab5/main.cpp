#include <iostream>
#include <csignal>
#include <cstring>

using std::cout;
using std::endl;

void handler_devide(int signum);
void handler_ptr(int signum);

int main(int argc, char* argv[]) {

    if (argc <= 1) {
        cout << "Не задан тип ошибки" << endl;
        return 0;
    }

    sigset_t set;
    sigemptyset(&set);
//    sigfillset(&set);
//    sigdelset(&set, SIGFPE);
//    sigdelset(&set, SIGSEGV);
    sigaddset(&set, SIGFPE);
    sigaddset(&set, SIGSEGV);
//    sigprocmask(SIG_SETMASK, &set, NULL);
    sigprocmask(SIG_UNBLOCK, &set, NULL);

    if (strcmp(argv[1], "SIGFPE") == 0) {
        signal(SIGFPE, handler_devide);

        int answer = 1/0;
        cout << "RESULT: " << answer << endl;
    } else if (strcmp(argv[1], "SIGSEGV") == 0) {
//        signal(SIGSEGV, handler_ptr);

        int* p = 0x00000000;
        *p = 10;
    } else
        cout << "Ошибка. Неверно введен тип ошибки" << endl;

    return 0;
}

void handler_devide(int signum) {
    cout << "Ошибка. Деление на ноль" << endl;
    exit(3);
}

void handler_ptr(int signum) {
    cout << "Ошибка. Нарушение защиты памяти" << endl;
    exit(3);
}