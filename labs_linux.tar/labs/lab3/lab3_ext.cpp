#include <iostream>

#include <unistd.h>

using std::cout;
using std::endl;

int main(int argc, char* argv[]) {

    if (argc < 1)
        cout << "Программа должна принимать имя процесса" << endl;


    cout << argv[1] << ": id процесса - " << getpid() << endl;
    cout << argv[1] << ": id предка - " << getppid() << endl;
    cout << argv[1] << ": id сессии процесса - " << getsid(getpid()) << endl;
    cout << argv[1] << ": id группа процессов - " << getpgid(getpid()) << endl;
    cout << argv[1] << ": реальный id пользователя - " << getuid() << endl;
    cout << argv[1] << ": эффективный идентификатор пользователя - " << geteuid() << endl;
    cout << argv[1] << ": реальный групповой идентификатор - " << getgid() << endl;
    cout << argv[1] << ": эффективный групповой идентификатор - " << getegid() << endl;
    return 0;
}