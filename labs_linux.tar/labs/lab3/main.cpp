#include <iostream>
#include <fstream>
#include <unistd.h>

using std::cout;
using std::endl;
using std::ofstream;
using std::ios_base;

void printAttributes(const char *, const char *);

int main(int argc, char* argv[]) {

    ofstream fout(argv[4], ios_base::trunc | ios_base::out);
//    fout << "PROGRAM: " << getpid() << endl
    printAttributes("PARENT", argv[4]);
    fout.close();

    if (fork() == 0) {
        sleep(static_cast<unsigned int>(atoi(argv[1])));
        printAttributes("CHILD 1", argv[4]);
        exit(0);
    }

    if (vfork() == 0) {
        sleep(static_cast<unsigned int>(atoi(argv[2])));
        printAttributes("CHILD 2", argv[4]);
        execl("lab3_ext", "lab3_ext", "CHILD 3", argv[3], argv[4], NULL);
        exit(0);
    }
    return 0;
}

void printAttributes(const char *name, const char* fname) {
    ofstream fout (fname, ios_base::app);

    fout << name << ": id процесса - " << getpid() << endl;
    fout << name << ": id предка - " << getppid() << endl;
    fout << name << ": id сессии процесса - " << getsid(getpid()) << endl;
    fout << name << ": id группа процессов - " << getpgid(getpid()) << endl;
    fout << name << ": реальный id пользователя - " << getuid() << endl;
    fout << name << ": эффективный идентификатор пользователя - " << geteuid() << endl;
    fout << name << ": реальный групповой идентификатор - " << getgid() << endl;
    fout << name << ": эффективный групповой идентификатор - " << getegid() << endl;

    fout.close();
}