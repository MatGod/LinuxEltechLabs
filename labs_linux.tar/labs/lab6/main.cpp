#include <iostream>
#include <sys/time.h>
#include <csignal>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>

using std::cout;
using std::endl;

static int iterations = 0;
static int count = 0;

void handler(int);
void output(bool);
void stopProgram(int);

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Ошибка. Программа должна принимать два аргумента" << endl;
        return 1;
    }

    signal(SIGTSTP, stopProgram);

    iterations = atoi(argv[1]);
    int interval = atoi(argv[2]);

    cout << "Iterations: " << iterations << " | Interval: " << interval << endl;

    struct sigaction sa;
    memset (&sa, 0, sizeof (sa));
    sa.sa_handler = &handler;
    sigaction (SIGALRM, &sa, NULL);

    struct itimerval timer;

    timer.it_value.tv_sec = interval;
    timer.it_value.tv_usec = 0;

    timer.it_interval.tv_sec = interval;
    timer.it_interval.tv_usec = 0;
    setitimer (ITIMER_REAL, &timer, NULL);

    while (1);
}

void handler(int signo) {
    pid_t childPid = fork();
    if(!childPid){
        output(false);
        return;
    }
    waitpid(childPid, NULL, 0);
    output(true);
    count++;
    if(count >= iterations)
        exit(0);
}

void output(bool isParent) {
    char buffer[255];
    time_t seconds = time(nullptr);
    tm* timeinfo = localtime(&seconds);
    char* format = const_cast<char *>("%d.%B.%Y %H:%M:%S");
    strftime(buffer, sizeof(buffer), format, timeinfo);
    cout << (isParent ? "Parent." : "Child.") <<" PID: " << getpid() << " TIME: " << buffer << endl;
    if (!isParent)
        _exit(0);
}

void stopProgram(int signum){
    cout << "Подождите пока программа завершится" << endl;
}