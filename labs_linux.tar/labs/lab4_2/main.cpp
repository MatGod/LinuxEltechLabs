#include <iostream>
#include <fstream>
#include <cstring>

using std::cout;
using std::endl;

void* threadFuncOdd(void*);
void* threadFuncEven(void*);
void cleanFile(const char*);

int main() {
    cleanFile("output1.txt");
    cleanFile("output2.txt");

    FILE* file = fopen("input.txt", "r");

    int status = 0;
    char str[255];

    while (fgets(str, sizeof(str), file) != nullptr) {
        pthread_t threadOdd;
        pthread_create(&threadOdd, nullptr, threadFuncOdd, (void*)str);
        pthread_join(threadOdd, (void**)status);

        if (fgets(str, sizeof(str), file) == nullptr)
            break;

        pthread_t threadEven;
        pthread_create(&threadEven, nullptr, threadFuncEven, (void*)str);
        pthread_join(threadOdd, (void**)status);
    }
    fclose(file);

    return 0;
}

void cleanFile(const char* fname) {
    FILE* file = fopen(fname, "w");
    fclose(file);
}

void* threadFuncOdd(void* args) {
    char* str = (char*)args;
    FILE* file = fopen("output1.txt", "a");
    fprintf(file, str);
    fclose(file);

    pthread_exit(0);
}

void* threadFuncEven(void* args) {
    char* str = (char*)args;
    FILE* file = fopen("output2.txt", "a");
    fprintf(file, str);
    fclose(file);

    pthread_exit(0);
}