#include <iostream>
#include <fstream>

using std::cout;
using std::endl;
using std::ifstream;

void* thread_func(void *args) {
    int fd = *((int*)(&args));
    FILE* file = fdopen(fd, "r");
    char str[255];
    while (fgets(str, sizeof(str), file) != nullptr)
        cout << str;
    cout << endl;
//    fclose(file);

    pthread_exit(0);
}

int main() {
    pthread_t thread;
    int status_addr = 0;

    FILE *file = fopen("out.txt", "r");
    int fd = fileno(file);
    if(pthread_create(&thread, nullptr, thread_func, (void*)fd) != 0)
        cout << "Ошибка. Не удалось создать поток" << endl;
    pthread_join(thread, (void**)status_addr);
    if (fclose(file) == 0)
        cout << "Файл принудительно закрыт" << endl;
    return 0;
}